package configuration

const (
	GroupName = "k8s.nginx.org"
)
