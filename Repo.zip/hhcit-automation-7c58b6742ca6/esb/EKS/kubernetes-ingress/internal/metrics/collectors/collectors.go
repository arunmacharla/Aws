package collectors

const metricsNamespace = "nginx_ingress_controller"
