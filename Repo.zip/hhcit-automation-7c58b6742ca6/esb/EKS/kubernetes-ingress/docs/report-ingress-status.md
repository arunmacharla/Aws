# Reporting Status of Ingress Resources

This doc is now available at https://docs.nginx.com/nginx-ingress-controller/configuration/global-configuration/reporting-resources-status/