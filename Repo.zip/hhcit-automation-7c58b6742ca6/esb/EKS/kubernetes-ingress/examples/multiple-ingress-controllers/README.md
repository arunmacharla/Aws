# Using Multiple Ingress Controllers

This example has been transformed into the [Multiple Ingress Controllers doc](../../docs/multiple-ingress-controllers.md).
