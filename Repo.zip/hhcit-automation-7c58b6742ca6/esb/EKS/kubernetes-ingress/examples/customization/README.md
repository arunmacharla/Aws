# Customization of NGINX Configuration

This example has been transformed into the [ConfigMap and Annotations doc](../../docs/configmap-and-annotations.md).