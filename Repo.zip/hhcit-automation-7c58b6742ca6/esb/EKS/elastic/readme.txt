https://www.elastic.co/guide/en/beats/filebeat/current/running-on-kubernetes.html
curl -L -O https://raw.githubusercontent.com/elastic/beats/7.6/deploy/kubernetes/filebeat-kubernetes.yaml

kubectl apply -f filebeat-kubernetes.yaml
