aws cloudformation create-stack --stack-name esb-criticaldates-tg --template-body file://esb_criticaldates-tg.yaml --parameters file://dev-tg-params.json --region us-east-2
aws cloudformation create-stack --stack-name esb-concur-tg --template-body file://concur-tg.yaml --parameters file://dev-tg-params.json --region us-east-2

