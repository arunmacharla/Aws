1. Run t1 first
2. Get SG created in t1 and update t2
3. Run t2
4. add SG created in 2 to all EC2 instances of the managed worker nodes


5. kubectl apply -f config_map.yaml
6. kubectl apply -f concurjdeexppaid_timer.yaml




ingress
Ref: https://aws.amazon.com/blogs/opensource/kubernetes-ingress-aws-alb-ingress-controller/
kubectl apply -f https://raw.githubusercontent.com/kubernetes-sigs/aws-alb-ingress-controller/v1.1.4/docs/examples/rbac-role.yaml
curl -sS "https://raw.githubusercontent.com/kubernetes-sigs/aws-alb-ingress-controller/v1.1.4/docs/examples/alb-ingress-controller.yaml"      | sed "s/# - --cluster-name=devCluster/- --cluster-name=hhc_intg_svc_dev/g" |kubectl apply -f -
