aws cloudformation create-stack --stack-name dev-tibco-eks-criticaldates-tg --template-body file://esb_criticaldates-tg.yaml --parameters file://esb_criticaldates-tg-params.json --region us-east-2
