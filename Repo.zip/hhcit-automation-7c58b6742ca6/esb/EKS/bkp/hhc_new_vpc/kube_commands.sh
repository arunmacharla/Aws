kubectl apply -f esb_criticaldates_deployment.yaml
kubectl apply -f esb_criticaldates_service.yaml
