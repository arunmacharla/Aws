#!/bin/sh


if [ -e $1 ];
then
echo "Usage: $0 <resource ids>"
exit 1
fi

aws --region us-east-2 ec2 create-tags --resources $@ --tags Key=Environment,Value=Development Key="OS Version",Value="Amazon Linux 2" Key="Division",Value="IT" Key="Group",Value="Enterprise Applications" Key="Owner",Value="Anand Soosai" Key="Project",Value="Integration Services" \
Key="HHC Business Unit",Value="Corp" Key="Cluster",Value="TIBCO EKS Dev" \
Key="Application ID",Value="TIBCO EKS Instance" Key="Application Role",Value="TIBCO Server" \
Key="Environment",Value="Development"
