aws cloudformation create-stack --stack-name dev-tibco-eks-stack --template-body file://dev-eks-control-plane.yml --parameters file://dev-eks-control-plane-params.json --region us-east-2

aws cloudformation create-stack --stack-name dev-tibco-eks-nodegroup-stack --template-body file://dev-eks-node-group.yml --parameters file://dev-eks-node-group-params.json --region us-east-2

aws cloudformation create-stack --stack-name dev-tibco-eks-ems-stack --template-body file://ems-server.yml --parameters file://ems-server-params.json --region us-east-2
