kubectl apply -f class.yaml
kubectl apply -f configmap.yaml
kubectl apply -f rbac.yaml
kubectl apply -f deployment.yaml
kubectl -n tibco-dev apply -f claim.yaml
