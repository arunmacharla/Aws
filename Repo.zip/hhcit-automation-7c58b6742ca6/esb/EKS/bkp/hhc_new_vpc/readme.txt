1. Run t1 first
2. Get SG created in t1 and update t2 to allow incoming 80/22 ports within private subnet
3. Run t2
4. Add SG created in 2 to all EC2 instances of the managed worker nodes
5. Add 22/80 inbound from within VPC to all workernodes via SG created for 22/80 inbound traffic
6. Mount EFS on both the worker nodes.
6. Now from bastion you should be able to access the worker nodes
7. create EMS server
8. EMS server EC2 users ec2-user account for login and has tibusr configured inside
9. Create ALB (public subnet) in the same VPC as above with default rule of fixed response on port 80
Ref: https://aws.amazon.com/premiumsupport/knowledge-center/public-load-balancer-private-ec2/
10. Add default VPC SG to ALB
11. Add Incoming port range requests from LB security group as a source into instance security group


7. Get kubeconfig for eks cluster created above
Ref. https://docs.aws.amazon.com/eks/latest/userguide/create-kubeconfig.html
- aws eks --region us-east-2 update-kubeconfig --name eks_hhc_intg_svc_dev
5. kubectl create namespace tibco-dev
5. kubectl apply -f dev_config_map.yaml
6. kubectl apply -f concurjdeexppaid_timer.yaml
8. Create PVs 


9. Update dev-tg-params.json with VPC and Listener ARN
11. execute lb_rules.sh
12. deploy esb service


ingress
Ref: https://aws.amazon.com/blogs/opensource/kubernetes-ingress-aws-alb-ingress-controller/
kubectl apply -f https://raw.githubusercontent.com/kubernetes-sigs/aws-alb-ingress-controller/v1.1.4/docs/examples/rbac-role.yaml
curl -sS "https://raw.githubusercontent.com/kubernetes-sigs/aws-alb-ingress-controller/v1.1.4/docs/examples/alb-ingress-controller.yaml"      | sed "s/# - --cluster-name=devCluster/- --cluster-name=hhc_intg_svc_dev/g" |kubectl apply -f -
