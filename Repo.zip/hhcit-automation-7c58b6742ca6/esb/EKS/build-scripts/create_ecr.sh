#!/bin/bash

export AWS_SECRET_ACCESS_KEY=${AWS_SECRET_ACCESS_KEY_DEV}
export AWS_ACCESS_KEY_ID=${AWS_ACCESS_KEY_ID_DEV}

if [ -z $REPONAME ]; then
  echo Repository name empty!
  exit 0
fi

echo Creating repository with name $REPONAME
aws ecr create-repository --region us-east-2 --repository-name $REPONAME
