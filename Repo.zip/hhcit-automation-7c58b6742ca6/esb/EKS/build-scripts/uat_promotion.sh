#!/bin/bash
# Author: Satish K. Pagare (satish@capiot.com)
# Production Kubernetes Environment Setup
# This script needs parameters set through a Jenkins job

export AWS_SECRET_ACCESS_KEY=${AWS_SECRET_ACCESS_KEY_DEV}
export AWS_ACCESS_KEY_ID=${AWS_ACCESS_KEY_ID_DEV}
export KUBECONFIG=${KUBECONFIG_DEV}
export K8S_ENV_UAT=tibco-uat
export K8S_DEPLOYMENT=$Deployment_Name
export RESTART_POD=0

env

export VER_PRESENT=`kubectl -n $K8S_ENV_UAT get deployment $K8S_DEPLOYMENT -o yaml | yq -r .spec.template.spec.containers[0].image | sed "s#.*:##g"`
echo INFO: Currrent Version deployed is: [$VER_PRESENT]

rm -f data.txt
rm -f job.failed

echo "Deployment status: $Deployment_Name - $CONTAINER_VERSION" | tee -a data.txt
echo "Deployment reason: $Reason" | tee -a data.txt

if [ $K8S_ConfigMap == true ]; then
  export RESTART_POD=1
  echo "- Configmap update" | tee -a data.txt
  echo ls -l esb/EKS/services/$K8S_DEPLOYMENT/uat/uat-configmap-*
  kubectl -n $K8S_ENV_UAT apply -f esb/EKS/services/$K8S_DEPLOYMENT/uat/uat-configmap-*
fi

if [ $K8S_Secret == true ]; then
  export RESTART_POD=1
  echo "- Secret update" | tee -a data.txt
  echo ls -l esb/EKS/services/$K8S_DEPLOYMENT/uat/uat-secret-*
  kubectl -n $K8S_ENV_UAT apply -f esb/EKS/services/$K8S_DEPLOYMENT/uat/uat-secret-*
fi

echo | tee -a data.txt

if [ $CodeDeploy = "true" ] && [ $CONTAINER_VERSION ] ; then
if [ -z $VER_PRESENT ]; then
  echo "ERROR: Deployment not found." | tee -a data.txt
  export CUR_STATE=fail
  touch job.failed
elif [ "$VER_PRESENT" = "$CONTAINER_VERSION" ];then
  echo "INFO: Version already deployed." | tee -a data.txt
  export CUR_STATE=present
  touch job.failed
else
  echo INFO: Setting Version to: [$CONTAINER_VERSION]
  export K8S_SERVICE_ECR_URL=`kubectl -n $K8S_ENV_UAT get deployment $K8S_DEPLOYMENT -o yaml | yq -r .spec.template.spec.containers[0].image | sed "s#:.*#:$CONTAINER_VERSION#g"`

  export K8S_CONTAINER=`kubectl -n $K8S_ENV_UAT get deployment $K8S_DEPLOYMENT -o yaml | yq -r .spec.template.spec.containers[0].name | sed "s#.*:##g"`

  echo INFO: K8S_CONTAINER : [$K8S_CONTAINER]
  echo INFO: K8S_SERVICE_ECR_URL : [$K8S_SERVICE_ECR_URL]

  kubectl -n $K8S_ENV_UAT set image deployments/${K8S_DEPLOYMENT} ${K8S_CONTAINER}=${K8S_SERVICE_ECR_URL}

  echo INFO: Waiting 15 seconds for pod to come online...
  sleep 15
  echo "kubectl -n $K8S_ENV_UAT rollout status deployment/${K8S_DEPLOYMENT} --timeout 120s" 
  WAIT_OUT=`kubectl -n $K8S_ENV_UAT rollout status deployment/${K8S_DEPLOYMENT} --timeout 120s`

  if [[ "${WAIT_OUT}" =~ "successfully rolled out" ]]; then
    echo INFO: $WAIT_OUT
    echo INFO: Deployment [$Deployment_Name] - [$CONTAINER_VERSION] was successful. | tee -a data.txt
  else
    touch job.failed
    echo ERROR: $WAIT_OUT | tee -a data.txt
    echo ERROR: Deployment [$CONTAINER_VERSION] failed
    echo "ERROR: Rolling back the deployment to [$VER_PRESENT]"| tee -a data.txt
    kubectl -n ${K8S_ENV_UAT} rollout undo deployment ${K8S_DEPLOYMENT}
  fi 
fi
else
  echo CodeDeploy/CONTAINER_VERSION not defined
  if [ $RESTART_POD == 1 ]; then
    echo Restarting POD for config updates
    kubectl -n $K8S_ENV_UAT rollout restart deployment/${K8S_DEPLOYMENT}
    echo INFO: Waiting 15 seconds for pod to come online...
    sleep 15
    kubectl -n $K8S_ENV_UAT rollout status deployment/${K8S_DEPLOYMENT} --timeout 120s
    WAIT_OUT=`kubectl -n $K8S_ENV_UAT rollout status deployment/${K8S_DEPLOYMENT} --timeout 120s`

    if [[ "${WAIT_OUT}" =~ "successfully rolled out" ]]; then
      echo INFO: $WAIT_OUT
      echo INFO: Deployment [$Deployment_Name] - [$CONTAINER_VERSION] was successful. | tee -a data.txt
    else
      touch job.failed
      echo ERROR: $WAIT_OUT | tee -a data.txt
      echo ERROR: Deployment [$CONTAINER_VERSION] failed
      echo "ERROR: Rolling back the deployment to [$VER_PRESENT]"| tee -a data.txt
      kubectl -n ${K8S_ENV_UAT} rollout undo deployment ${K8S_DEPLOYMENT}
    fi 
  fi
fi

echo "More Details: $BUILD_URL" | tee -a data.txt
cat data.txt
