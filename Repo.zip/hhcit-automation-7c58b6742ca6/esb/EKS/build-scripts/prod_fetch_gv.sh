#!/bin/bash 
# Author: Satish K. Pagare (satish@capiot.com)
# Get Kubernetes Config Map
# This script needs parameters set through a Jenkins job

export AWS_SECRET_ACCESS_KEY=${AWS_SECRET_ACCESS_KEY_PROD}
export AWS_ACCESS_KEY_ID=${AWS_ACCESS_KEY_ID_PROD}
export K8S_ENV=tibco-prod
export KUBECONFIG=$KUBECONFIG_PROD
export K8S_DEPLOYMENT=$Deployment_Name

export CONFIGMAP=`kubectl -n $K8S_ENV get deployment $Deployment_Name -o yaml | yq -r .spec.template.spec.containers[0].envFrom[0].configMapRef.name`
export SECRET=`kubectl -n $K8S_ENV get deployment $Deployment_Name -o yaml | yq -r .spec.template.spec.containers[0].envFrom[1].secretRef.name`

if [ -z "${CONFIGMAP}" ]; then
        echo ERROR: No config map found for $Deployment_Name
else
	kubectl -n $K8S_ENV get configmap $CONFIGMAP -o yaml
fi

if [ -z "${SECRET}" ]; then
        echo ERROR: No secret found for $Deployment_Name
else
	kubectl -n $K8S_ENV get secret $SECRET -o yaml
fi
