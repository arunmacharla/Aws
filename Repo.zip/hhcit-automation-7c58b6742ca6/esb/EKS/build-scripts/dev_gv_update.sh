#!/bin/bash
# Author: Satish K. Pagare (satish@capiot.com)
# Development Kubernetes configmap setup

export GV_DONE=$WORKSPACE/gv_update_done

rm -f $GV_DONE
export K8S_NAMESPACE=tibco-dev
echo INFO: This script is only for Jenkins.
services=`grep esb/EKS/services/esb- $JENKINS_HOME/jobs/$JOB_BASE_NAME/builds/$BUILD_NUMBER/changelog.xml | egrep -e "dev-configmap|dev-secret" | awk '{print $6}' | sort -u`
export AWS_SECRET_ACCESS_KEY=$AWS_SECRET_ACCESS_KEY_DEV
export AWS_ACCESS_KEY_ID=$AWS_ACCESS_KEY_ID_DEV
for i in $services;
do
  echo "INFO: GV UPDATE [$i]"
  export SERVICE_DIR=`dirname $i`
  if [ -d $SERVICE_DIR ]; then
    echo "INFO: Changing directory to [$SERVICE_DIR]"
    basename `echo $SERVICE_DIR | sed 's/dev$//g' ` >> $GV_DONE
    cd $SERVICE_DIR
    PODPATTERN=`yq .metadata.name eks_esb*deployment.yaml  -r`
    echo "INFO: Applying configmap" dev-configmap-*.yaml
    kubectl -n $K8S_NAMESPACE apply -f dev-configmap-*.yaml
    RETURN=$?
    if [ $RETURN == 1 ]; then
      echo ERROR: Failed to apply configmap
      exit $RETURN
    fi
    if [ -f dev-secret-*.yaml ]; then
      echo "INFO: Applying configmap" dev-secret-*.yaml
      kubectl -n $K8S_NAMESPACE apply -f dev-secret-*.yaml
      RETURN=$?
      if [ $RETURN == 1 ]; then
        echo ERROR: Failed to apply secret
        exit $RETURN
      fi
    fi
    echo "INFO: Deleting POD [$PODPATTERN]"
    if [ -z ${PODPATTERN} ]; then
      echo ERROR: Null pod pattern
    else 
      kubectl -n $K8S_NAMESPACE delete pod `kubectl -n $K8S_NAMESPACE get pods | grep $PODPATTERN- | awk '{print $1}'`
    fi
    cd $WORKSPACE
  fi
done
