#!/bin/bash
# Author: Satish K. Pagare - satish@capiot.com
export AWS_SECRET_ACCESS_KEY=$AWS_SECRET_ACCESS_KEY_DEV
export AWS_ACCESS_KEY_ID=$AWS_ACCESS_KEY_ID_DEV
aws ecr describe-repositories --region us-east-2 > all-repos.json
export REPOS=`cat all-repos.json | jq -r '.repositories|length'`
echo ++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
for i in $(seq 0 1 $REPOS)
do
  rm -f images.json.1
  rm -f images.json.2
  export REPONAME=`cat all-repos.json | jq -r .repositories[$i].repositoryName`
  if [ $REPONAME == "null" ];
    then 
    # DO NOTHING
    echo -n
  else
    aws ecr list-images --repository-name $REPONAME --region us-east-2 > images.json.1
    export IDS=`cat images.json.1 | jq -r '.imageIds|length'`
    echo ECR Repo: $REPONAME total: $IDS
    for j in $(seq 0 1 $IDS)
    do
      export TAG=`cat images.json.1 | jq -r .imageIds[$j].imageTag`
      if [ $TAG == "null" ];
        then 
        echo -n
      else
        echo "			`cat images.json.1 | jq -r .imageIds[$j].imageTag`" >> images.json.2
      fi
    done
    sort -r images.json.2
    echo ++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
  fi
done
