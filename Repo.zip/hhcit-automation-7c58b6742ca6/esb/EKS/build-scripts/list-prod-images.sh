#!/bin/bash
# Author: Satish K. Pagare - satish@capiot.com
export AWS_SECRET_ACCESS_KEY=$AWS_SECRET_ACCESS_KEY_PROD
export AWS_ACCESS_KEY_ID=$AWS_ACCESS_KEY_ID_PROD
export KUBECONFIG=$KUBECONFIG_PROD
export K8S_NAMESPACE=tibco-prod
echo "------------------------------------------------------------"
printf "|%-41s| %-15s|\n" " Image Name" "Version"
echo "------------------------------------------------------------"
kubectl -n $K8S_NAMESPACE get deployments -o yaml > tmp_d.out
grep "image: " tmp_d.out | awk -F/ '{print $3}' | awk -F: '{printf "| %-40s|  %-14s|\n", $1,$2}' 
echo "------------------------------------------------------------"
