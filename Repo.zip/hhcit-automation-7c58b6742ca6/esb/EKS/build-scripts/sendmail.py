import smtplib
import base64
import os
import sys


num = len(sys.argv)
if num < 3 :
  print "Usage: python sendmail.py \"<subject>\" \"<status>\""
  sys.exit(1)

subject = sys.argv[1]
status = sys.argv[2]

sendto = 'satish.pagare@howardhughes.com'
sendto = 'tibcodevteam@howardhughes.com'
user= 'tibco-alerts@howardhughes.com'
secret= os.environ["HHC_EMAIL_CREDS"]
password = base64.b64decode(secret)
smtpsrv = "smtp.office365.com"
smtpserver = smtplib.SMTP(smtpsrv,587)

smtpserver.ehlo()
smtpserver.starttls()
smtpserver.ehlo
smtpserver.login(user, password)
#header = 'To:' + sendto + '\n' + 'From: ' + user + '\n' + 'Subject:testing... \n'
header = 'To:' + sendto + '\n' + 'From: ' + user + '\n' + 'Subject: ' + subject + " - " + status + '\n'
msgbody = header + '\n Hello,\n\n'

with open ("data.txt", "r") as myfile:
    data=myfile.read()
msgbody = msgbody + data + "\n Thanks and Regards,\n Team TIBCO DevOps\n"

print 'Sending email.'
smtpserver.sendmail(user, sendto, msgbody)
smtpserver.close()
