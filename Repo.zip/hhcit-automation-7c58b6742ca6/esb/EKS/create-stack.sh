aws cloudformation create-stack --stack-name dev-tibco-eks-stack --template-body file://dev-eks-control-plane.yml --parameters file://dev-eks-control-plane-params.json --region us-east-2

aws cloudformation create-stack --stack-name dev-tibco-eks-nodegroup-stack --template-body file://dev-eks-node-group.yml --parameters file://dev-eks-node-group-params.json --region us-east-2

aws cloudformation create-stack --stack-name dev-tibco-eks-ems-stack --template-body file://ems-server.yml --parameters file://ems-server-params.json --region us-east-2

aws cloudformation create-stack --stack-name dev-tibco-eks-njams-stack --template-body file://njams-servers.yml --parameters file://njams-servers-params.json --region us-east-2

aws cloudformation create-stack --stack-name dev-tibco-eks-concurjdeexpprocessing-tg --template-body file://aws_esb-concurjdeexpprocessing-tg.yaml --parameters file://aws_esb-concurjdeexpprocessing-tg-params.json --region us-east-2

aws cloudformation create-stack --stack-name dev-tibco-eks-teamwork-tg --template-body file://aws_esb-teamwork-tg.yaml --parameters file://aws_esb-teamwork-tg-params.json --region us-east-2
